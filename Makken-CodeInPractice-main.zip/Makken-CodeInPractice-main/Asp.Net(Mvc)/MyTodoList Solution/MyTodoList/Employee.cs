﻿namespace MyTodoList
{
    public class Employee
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
