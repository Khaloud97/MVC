﻿namespace ConsoleApp1
{
    class Program
    {
      static void Main() {

          Console.Write("Yousif");
          Console.WriteLine("Hello world");
          Console.Write("Makeen");
            Console.ReadLine();-
                
        }
    }
}
