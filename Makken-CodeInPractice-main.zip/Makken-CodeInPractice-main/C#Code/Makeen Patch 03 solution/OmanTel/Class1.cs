﻿namespace OmanTel
{
    public class Class1
    {

    }
}