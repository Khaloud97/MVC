﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Makeen_Patch03_Version02.Users
{
    internal class Human
    {
        public int id;
        public int SSN;

        public string name;
        public string Jobdescription;
        public bool IsMarried;




    }
}
