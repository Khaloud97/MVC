export default function CustomValidation(username , password , email , age)
{
    return `${username} || ${password}  || ${email} ${age}` 
}
