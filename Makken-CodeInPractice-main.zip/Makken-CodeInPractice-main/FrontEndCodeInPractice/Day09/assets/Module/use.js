import CustomValidation from "./CustomValidation";


let output = CustomValidation("yousif" , "#######" , "yousifm836@gmail.com" , 26)
console.log(output)