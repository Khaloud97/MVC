// let x = 3 ; //Deceleration

// // let x = 4 ;  // Doesn't Allow the Redeclaration

// const y = "Hola Const" ; 

// // y= "holathere" ; 
// // will Raise error as Constant 
// // Doesn't allow the Redecleration

// console.log(y)


// //---------------------------------------------
// let z  = function(x,y) {
//     return x*y ; 
// }

// z(1,2);  

// let xz = (x, y = 3) => x*y ;
// xz(2); // will return 6
// xz(3,4); // will Return 12 

// let msg = " hello mr " ; 
// let name  = "admin" ;
// //before Ecma 6 
// console.log(msg + " " + name + "we are glad to see you with us  !");
// // with Ecma6
// console.log(`${msg} ${name} we are glad to see you with us  !`);
//-----------------------------------------------------------------
// let user = {
//     name : "yousif" , 
//     age : 26 , 
//     position : "SoftwareEngineer"
// }

// // before for destructing an object 
// // let name  = user.name ; 
// // let age = user.age ; 
// // let position = user.position ;

// // After EcmaScript 6 
// let { name , age , position } = user ;



// }
// export default CustomValidation ;
