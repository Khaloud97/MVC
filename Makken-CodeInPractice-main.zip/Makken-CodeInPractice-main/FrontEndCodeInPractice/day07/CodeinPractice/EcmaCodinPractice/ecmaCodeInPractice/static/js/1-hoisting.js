
"use strict"
function func1(){
    var x = 10 ; 
    console.log(i);
        for (var i = 0; i < x; i++) {
            console.log(i);
            
        }
        console.log(i);
    }

    func1();
console.log("---------------------------------")
//------------------------------------
 for (var i = 0; i < 10; i++) {
    console.log(i);
    
 }   

 console.log(i)

 const pi  = 3.14 ; // has to be decleared and initialized 

//Block scope  
 for (let index = 0; index < array.length; index++) {
    const element = array[index];
    
 }